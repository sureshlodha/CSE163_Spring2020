# D3-visualization for Class Enhancement Project

## added new functionality to legends so we can compare different the number of influential women from different continents

old version: https://parvinDaD.github.io/D3-visualization/

new version: https://minhanhn98.github.io/class%20enhancement/