Displays the classes (both required and optional electives) offerred for Computer Science majors at UCSC. This visualization provides a list and description (via tooltip) of each class in a format that helps students weigh their options and choose which classes they want to take. Color scale also depicts the requirements the class can fulfill, or if it is a required class in the major.

https://sriyalingampalli.github.io/UCSC_CS_Classes/UCSCclasses

Created by Sriya Lingampalli in collaboration with Professor Suresh Lodha in CSE 163: Data Visualization, Spring 2020