# TimelineComparison
Visualization showing schedules and making comparisons between them by showing stacked area plot
The site is on: https://saujanyam.github.io/TimelineComparison/
